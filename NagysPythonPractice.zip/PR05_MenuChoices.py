""" 
File: PR05_MenuChoices.py
Requirements: PT05_MenuChoices.pdf
"""

# TODO: Your solution goes here!
