""" 
File: PR11_PasswordEncoder.py
Requirements: PT11_PasswordEncoder.pdf
"""

# TODO: Your solution goes here!
