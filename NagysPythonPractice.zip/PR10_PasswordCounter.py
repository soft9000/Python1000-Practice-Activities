""" 
File: PR10_PasswordCounter.py
Requirements: PT10_PasswordCounter.pdf
"""

# TODO: Your solution goes here!
